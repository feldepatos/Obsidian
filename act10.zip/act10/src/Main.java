import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String palabra1;
        String palabra2;
        String palabra3;
    Scanner reader= new Scanner(System.in);
        System.out.println("dime dos palabras");
        palabra1= reader.nextLine();
        palabra2= reader.nextLine();
        palabra3= reader.nextLine();
        System.out.println("La palaba mas larga es "+max(palabra1,palabra2,palabra3));


    }
    static String max(String a, String b,String c) {
        String mayor;
        if (a.length() < b.length() && a.length() < c.length()) {
            mayor = a;
        }
        else if (b.length() < a.length() && b.length() < c.length()) {
            mayor = b;
        } else {
            mayor = c;
        }
    }
}
